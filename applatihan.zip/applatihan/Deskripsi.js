import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const Deskripsi = ({ route }) => {
  const { judul, deskripsi, agama, tanggalLahir, umur, status, gambar } = route.params;

  return (
    <View style={styles.container}>
      <Image source={gambar} style={styles.img} />
      <View style={styles.teks}>
        <Text style={styles.title}>{judul}</Text>
        <Text>{deskripsi}</Text>
        <Text>Agama: {agama}</Text>
        <Text>Tanggal Lahir: {tanggalLahir}</Text>
        <Text>Umur: {umur}</Text>
        <Text>Status: {status}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  img: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  teks: {
    alignItems: 'center',
  },
  title: {
    fontWeight: 'bold',
    fontSize: 20,
    marginBottom: 10,
  },
});

export default Deskripsi;