import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { View } from 'react-native';

import Contact from './components/Kontak';
import DeskripsiTeman from './Deskripsi';

const Stack = createStackNavigator();

const friends = [
  { id: 1, name: "Ages Gelar Pangestu", telepon: "08121985140", deskripsi: "Deskripsi Ages", gambar: require('./assets/eren.jpg'), agama: "Islam", tanggalLahir: "30 Maret 835", umur: 19, status: "Aktif" },
  { id: 2, name: "Arya Pangestu", telepon: "08121985141", deskripsi: "Deskripsi Arya", gambar: require('./assets/mikasa.jpg'), agama: "Islam", tanggalLahir: "10 Februari 835", umur: 19, status: "Aktif" },
  { id: 3, name: "Luthfi Fauzan", telepon: "08121985142", deskripsi: "Deskripsi Luthfi", gambar: require('./assets/armin.jpg'), agama: "Islam", tanggalLahir: "3 November 835", umur: 19, status: "Aktif" },
];

function HomeScreen({ navigation }) {
  return (
    <View>
      {friends.map((friend) => (
        <Contact
          key={friend.id}
          gambar={friend.gambar}
          judul={friend.name}
          telepon={friend.telepon}
          deskripsi={friend.deskripsi}
          agama={friend.agama}
          tanggalLahir={friend.tanggalLahir}
          umur={friend.umur}
          status={friend.status}
          navigation={navigation}
        />
      ))}
    </View>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Deskripsi Teman" component={DeskripsiTeman} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}