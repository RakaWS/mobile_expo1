import React from 'react'
import {Text,View,StyleSheet,Button} from 'react-native';

const About =({navigation}) => {
  return(
    <View>
      <Text>About Screen</Text>
      <Button title="Go Back" onPress={()=>navigation.goback()}/>
    </View>
  );
};

export default About;